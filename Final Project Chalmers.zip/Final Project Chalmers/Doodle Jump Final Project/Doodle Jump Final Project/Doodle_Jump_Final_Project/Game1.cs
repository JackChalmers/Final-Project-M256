using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Doodle_Jump_Final_Project
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Rectangle doodleCharRect;
        Texture2D doodleCharImg, JumperRight,JumperLeft;

        bool bJumperInAir = false;
        int jumperCurYSpeed = 0;
        int MAX_JUMPER_Y_SPEED = 23;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            doodleCharRect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 30, GraphicsDevice.Viewport.Height - 80, 60, 60);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            doodleCharImg = Content.Load<Texture2D>("doodle bunny Right");
            JumperLeft = Content.Load<Texture2D>("doodle bunny");
            JumperRight = Content.Load<Texture2D>("doodle bunny Right");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            KeyboardState curKeys = Keyboard.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            if(bJumperInAir == false)
            {
                bJumperInAir = true;
                jumperCurYSpeed = MAX_JUMPER_Y_SPEED;
            }

            if(bJumperInAir)
            {
                doodleCharRect.Y -= jumperCurYSpeed;
                jumperCurYSpeed--;

                if(doodleCharRect.Y >= 400)
                {
                    bJumperInAir = false;
                }
            }
            
            if (curKeys.IsKeyDown(Keys.A))
            {
                doodleCharRect.X-=10;
                doodleCharImg = JumperLeft;
            }
                
            if (curKeys.IsKeyDown(Keys.D))  
            {
                doodleCharRect.X+=10;
                doodleCharImg = JumperRight;
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            spriteBatch.Begin();
           
            spriteBatch.Draw(doodleCharImg, doodleCharRect, Color.White);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
