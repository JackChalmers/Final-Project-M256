using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Doodle_Jump_Final_Project
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    /// 

    public class PlatformSprite
    {
        //Image
        private Texture2D m_Img;

        //rectangle
        public Rectangle m_PlatRect;

        public PlatformSprite(int x, int y, int width, int height, Texture2D img)
        {
            m_Img = img;
            m_PlatRect = new Rectangle(x, y, width, height);
        }

        public void drawPlatform(SpriteBatch sb)
        {
            sb.Draw(m_Img, m_PlatRect, Color.White);
        }

    }

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Rectangle doodleCharRect;
        Texture2D doodleCharImg, JumperRight, JumperLeft, platformImg;
        PlatformSprite[] platArray;

        byte bgColorNumGreen = 255, bgColorNumBlue = 255;
        int numberColorUsedG = 0, numberColorUsedB = 0, TOTAL_PLATFORMS, levelNumber = 1, platLocation, randPlaceHolder;
        Color backgroundColor;
        float bgColorTimerGreen = 0, bgColorTimerBlue = 0;
        Random rnd = new Random();

        Texture2D instructionImg;
        Rectangle instructionRect;

        bool bPauseGame = false;
        Rectangle pauseRect;
        Texture2D pauseImgBg;
        SpriteFont pauseFont, PauseFontDark;
        
        KeyboardState curKeys;
        KeyboardState oldkeys;
        string gameState = "instructionScreen";


        bool bJumperInAir = false;
        int jumperCurYSpeed = 0;
        int MAX_JUMPER_Y_SPEED = 20;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            doodleCharRect = new Rectangle(GraphicsDevice.Viewport.Width / 2 - 30, GraphicsDevice.Viewport.Height - 80, 60, 60);
            backgroundColor = new Color(51, bgColorNumGreen, 255);
            TOTAL_PLATFORMS = levelNumber * 10;
            instructionRect = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            pauseRect = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            doodleCharImg = Content.Load<Texture2D>("doodle bunny Right");
            JumperLeft = Content.Load<Texture2D>("doodle bunny");
            JumperRight = Content.Load<Texture2D>("doodle bunny Right");
            platformImg = Content.Load<Texture2D>("Doodle_Platforms Single Green");
            instructionImg = Content.Load<Texture2D>("doodle jump start screen");
            pauseImgBg = Content.Load<Texture2D>("pause screen blank");

            pauseFont = Content.Load<SpriteFont>("SpriteFont1");
            PauseFontDark = Content.Load<SpriteFont>("BackGroundPause");

            platArray = new PlatformSprite[TOTAL_PLATFORMS];
            for (int i=0; i<TOTAL_PLATFORMS; i++)
            {
                platArray[i] = new PlatformSprite(doodleCharRect.X + 50, doodleCharRect.Y - 100, 75, 25, platformImg);
            }

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            KeyboardState curKeys = Keyboard.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || curKeys.IsKeyDown(Keys.Escape))
                this.Exit();

            
            if (curKeys.IsKeyDown(Keys.P) && oldkeys.IsKeyUp(Keys.P))
                if (bPauseGame == false)
                    bPauseGame = true;
                else if (bPauseGame == true)
                    bPauseGame = false;

            if (curKeys.IsKeyDown(Keys.R) && oldkeys.IsKeyUp(Keys.R))
                bPauseGame = false;

            if (curKeys.IsKeyDown(Keys.O) && oldkeys.IsKeyUp(Keys.O) && bPauseGame == true)
            {
                bPauseGame = false;
                gameState = "instructionScreen";

            }
                

            if (gameState == "instructionScreen")
            {
                if(curKeys.IsKeyDown(Keys.Space))
                {
                    gameState = "gamePlay";
                }
            }

            else if (gameState == "gamePlay" && bPauseGame == false)
            {

                if (bJumperInAir == false)
                {
                    bJumperInAir = true;
                    jumperCurYSpeed = MAX_JUMPER_Y_SPEED;
                }

                if (bJumperInAir)
                {
                    doodleCharRect.Y -= jumperCurYSpeed;
                    jumperCurYSpeed--;

                    if (doodleCharRect.Y >= GraphicsDevice.Viewport.Height - 75)
                    {
                        bJumperInAir = false;
                    }
                }

                if (curKeys.IsKeyDown(Keys.A))
                {
                    doodleCharRect.X -= 10;
                    doodleCharImg = JumperLeft;
                }

                if (curKeys.IsKeyDown(Keys.D))
                {
                    doodleCharRect.X += 10;
                    doodleCharImg = JumperRight;
                }
                if (doodleCharRect.X <= 0 - doodleCharRect.Width)
                    doodleCharRect.X = GraphicsDevice.Viewport.Width;
                if (doodleCharRect.X > GraphicsDevice.Viewport.Width + doodleCharRect.Width)
                    doodleCharRect.X = 0 - doodleCharRect.Width;

                if (numberColorUsedG < 17) // light blue to dark blue
                {
                    bgColorTimerGreen++;
                    if (bgColorTimerGreen % 90 == 0)
                    {
                        bgColorNumGreen -= 15;
                        backgroundColor = new Color(0, bgColorNumGreen, 255);
                        numberColorUsedG++;
                    }
                }

                if (numberColorUsedG >= 17 && numberColorUsedB < 17) // dark blue to black
                {
                    bgColorTimerBlue++;
                    if (bgColorTimerBlue % 90 == 0)
                    {
                        bgColorNumBlue -= 15;
                        backgroundColor = new Color(0, 0, bgColorNumBlue);
                        numberColorUsedB++;
                    }
                }

                if (numberColorUsedB == 18) // keep black so dont flash
                    backgroundColor = new Color(0, 0, 0);

                randPlaceHolder = rnd.Next(1, 3);
                if (randPlaceHolder == 1)
                {
                    platLocation = doodleCharRect.X + 50;
                }
                if (randPlaceHolder == 2)
                {
                    platLocation = doodleCharRect.X - 50;
                }
                if (randPlaceHolder == 3)
                {

                }


                for (int i = 0; i < TOTAL_PLATFORMS; i++)
                {
                    if (doodleCharRect.Intersects(platArray[i].m_PlatRect))
                    {
                        bJumperInAir = false;
                        for (int j = 0; j < 1; j++)
                        {
                            platArray[i].m_PlatRect.Y += 50;
                        }
                    }
                }
            }

            oldkeys = curKeys;
                    base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(backgroundColor);
            Vector2 ResumeVector = new Vector2(GraphicsDevice.Viewport.Width / 2 - 100, 150); // text for when BG is light
            Vector2 QuitInstVector = new Vector2(GraphicsDevice.Viewport.Width / 2 - 100, 175);
            Vector2 QuitGameVector = new Vector2(GraphicsDevice.Viewport.Width / 2 - 100, 200);
            Vector2 ScoreVector = new Vector2(15, GraphicsDevice.Viewport.Height - 40);

            Vector2 ResumeVectorDark = new Vector2(GraphicsDevice.Viewport.Width / 2 - 100, 150); // text for when BG is dark
            Vector2 QuitInstVectorDark = new Vector2(GraphicsDevice.Viewport.Width / 2 - 100, 175);
            Vector2 QuitGameVectorDark = new Vector2(GraphicsDevice.Viewport.Width / 2 - 100, 200);
            Vector2 ScoreVectorDark = new Vector2(15, GraphicsDevice.Viewport.Height - 40);


            spriteBatch.Begin();

            if(gameState == "instructionScreen")
            {
                spriteBatch.Draw(instructionImg, instructionRect, Color.White);
            }
            else if (gameState == "gamePlay" && bPauseGame == false)
            {

                spriteBatch.Draw(doodleCharImg, doodleCharRect, Color.White);
                for (int i = 0; i < TOTAL_PLATFORMS; i++)
                {
                    platArray[i].drawPlatform(spriteBatch);

                }
            }
            else if (bPauseGame == true)
            {
                spriteBatch.Draw(pauseImgBg, pauseRect, backgroundColor);
                if (numberColorUsedG >= 17)
                {
                    spriteBatch.DrawString(PauseFontDark, "Resume: Press R", ResumeVectorDark, Color.White);
                    spriteBatch.DrawString(PauseFontDark, "Quit to Instruction: Press O", QuitInstVectorDark, Color.White);
                    spriteBatch.DrawString(PauseFontDark, "Quit Game: Press Escape", QuitGameVectorDark, Color.White);
                    spriteBatch.DrawString(PauseFontDark, "Score:", ScoreVectorDark, Color.White);
                }
                else
                {
                    spriteBatch.DrawString(pauseFont, "Resume: Press R", ResumeVector, Color.Black);
                    spriteBatch.DrawString(pauseFont, "Quit to Instruction: Press O", QuitInstVector, Color.Black);
                    spriteBatch.DrawString(pauseFont, "Quit Game: Press Escape", QuitGameVector, Color.Black);
                    spriteBatch.DrawString(pauseFont, "Score:", ScoreVector, Color.Black);
                }
                
            }

                spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
